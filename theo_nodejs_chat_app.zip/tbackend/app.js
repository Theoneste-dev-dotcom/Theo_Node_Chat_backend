const express = require('express');
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');
const mongoose = require('mongoose');
const Message = require('./models/chatMessage')
const FriendMessage = require('./models/friendMessage')

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "http://localhost:5173",
        methods: ["GET", "POST"]
    }
});

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const router = require('./routes/user');
const messageRouter = require('./routes/messages')
const chatRouter = require('./routes/chatRoom');
const friendRouter = require('./routes/friendMessage')
app.use('/', chatRouter);
app.use('/', messageRouter)
app.use('/', router);
app.use('/', friendRouter)

mongoose.connect("mongodb://127.0.0.1:27017/chat")
    .then(() => {
        console.log("connected to database");
    })
    .catch(error => {
        console.log("failed to connect", error);
    });

io.on('connection', (socket) => {
    console.log('connected', socket.id);

    socket.on('join', (room) => {
        socket.join(room);
        const message = "Welcome to " + room;
        socket.emit('message', message);
    });

    socket.on('group_message', ({ group, gmsg }) => {
        const message = new Message({ group, message: gmsg });
        message.save().then(() => {
            io.to(group).emit('message', gmsg);
        }).catch(err => {
            console.error("Error saving message:", err);
        });
    });

    socket.on('chat-messages',message=>{
        socket.emit('chats', message.msg)
        const newChat = new FriendMessage({senderId: message.user, receiver_name: message.name, message:message.msg})
        newChat.save()
        socket.emit('chat-message', message.msg)
    })

    socket.on("disconnect", () => {
        console.log("disconnected " + socket.id);
    });
});

const PORT = process.env.PORT || 8001;
server.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT}`);
});
