
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const User = require('../models/userModel')
exports.login = async (req, res) => {

    const { email, password } = req.body

    const user = User.findOne({ email: email })
    if (user) {
        let match = bcrypt.compare(password, user.password)
        if (match) {
            const token = jwt.sign({ id: user._id },'secret-key')
            res.json({
                message: "user logged in successfully",
                token
            })
        }
    } else {
        console.log("Email and password did not match")
    }

}
exports.register = async (req, res) => {
    const { name, email, password } = req.body
    

    const hahed = await bcrypt.hash(password, 10)
    const user = new User({ name, email, password:hahed})
    await user.save()
    res.status(200).json({
        message: "user saved successfully"
    })
}