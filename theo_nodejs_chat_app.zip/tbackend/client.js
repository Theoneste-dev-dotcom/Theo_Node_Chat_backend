import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import io from 'socket.io-client';

const socket = io("http://localhost:8000");

function Dashboard() {
    const [groups, setGroups] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:8000/get/chatrooms')
            .then(res => {
                console.log("Fetched chat rooms:", res.data);
                setGroups(res.data.chatRooms);
            })
            .catch(err => {
                console.error("Error fetching chat rooms:", err.message);
            });

        socket.on('connect', () => {
            console.log('Socket connected:', socket.id);
        });

        socket.on('disconnect', () => {
            console.log('Socket disconnected');
        });

        return () => {
            socket.off('connect');
            socket.off('disconnect');
        };
    }, []);

    const [roomName, setRoomName] = useState({ name: "" });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setRoomName(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post("http://localhost:8000/create/chatroom", roomName)
            .then(res => {
                console.log("Chat room created:", res.data);
                setGroups([...groups, res.data]);
            })
            .catch(err => {
                console.error("Error creating chat room:", err.message);
            });
    };

    return (
        <div className='flex flex-col items-center gap-3 mt-4 bg-white shadow-brown-100 shadow-xl mx-auto w-[70vw] p-5'>
            <h1 className='text-bold text-blue-950  font-bold text-2xl'>CHAT ROOM</h1>
            <form onSubmit={handleSubmit} className='flex flex-col gap-4  bg-white shadow-lg shados-black p-4 gap-3 w-[70%]'>
                <label className='text-blue-950 text-xl font-bold text-center' htmlFor="roomName">Chat Room Name</label>
                <input
                    onChange={handleChange}
                    name='name'
                    className='bg-gray-100 focus:bg-gray-300 text-blue-950 focus:border-none focus:outline-none text-xl py-2 text-center'
                    type="text"
                    placeholder='chat room name'
                    id='roomName'
                />
                <button type='submit' className='bg-orange-200 rounded-xl inline px-4 py-2 text-blue-500 font-bold text-xl'>Create ChatRoom</button>
            </form>
            <div className='w-[100%] h-[10vh] border-b-2 border-orange-200'></div>

            <h4 className='mb-4 font-bold text-blue-950 text-2xl mt-4'>GROUPS</h4>

            <div className='chat rooms w-[100%] bg-yellow-100'>
                <div className='chatroom flex flex-col gap-3'>
                    {groups.map((group, id) => (
                        <div className='flex gap-2 items-center justify-between' key={id}>
                            <div className='text-2xl font-bold text-blue-950'>{group.name}</div>
                            <div className='join bg-orange-200 rounded-xl inline px-4 py-2 text-blue-600 font-bold text-xl'>
                                <Link to={`/group/${group._id}`} className='bg-brown-400 font-bold text-xl text-blue-500 m-4 p-3'>JOIN GROUP</Link>
                            </div>
                        </div>
                    ))}
                </div>
                <div className='w-[100%] h-[10vh] border-b-2 border-orange-200 mt-12'></div>
            </div>
            <div className='flex items-center justify-center'>
                <Link to='/friend' className='rounded-xl inline px-4 py-2 text-blue-600 font-bold text-xl bg-orange-200'>YOUR FRIENDS</Link>
            </div>
        </div>
    );
}

export default Dashboard;
