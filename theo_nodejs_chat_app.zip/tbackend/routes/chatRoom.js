const express = require('express')
const chatRouter = express.Router()
const ChatRoom = require('../models/chatGroup')


chatRouter.post("/create/chatroom", async (req, res) => {
    const { name } = req.body
    const chatroom = new ChatRoom({
        name
    })
    chatroom.save()
    res.status(200).json({
        message:"chat room created",
        chatroom
    })
})

chatRouter.get("/get/chatrooms", async (req, res) => {
   const chatRooms =  await ChatRoom.find()
   try {     
    res.status(200).json({
        message:"chat rooms fetched",
        chatRooms:chatRooms
    })
   } catch (error) {
    console.log(error)
   }

})


chatRouter.get("/get/group/:id", async (req, res) => {
    const id = req.params.id
    const specific =  await ChatRoom.findById(id)
    try {     
     res.status(200).json({
         message:"chat rooms fetched",
         chatGroup:specific
     })
    } catch (error) {
     console.log(error)
    }
})
module.exports = chatRouter