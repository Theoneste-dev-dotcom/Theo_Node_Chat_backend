const express= require('express')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const router = express.Router()
const User = require('../models/userModel')
router.post('/login', async (req, res) => {
    const { email, password } = req.body

    try {
        const user = await User.findOne({ email: email })
        if (user) {
            const match = await bcrypt.compare(password, user.password)
            if (match) {
                const token = jwt.sign({ id: user._id }, 'secret-key')
                res.json({
                    message: "user logged in successfully",
                   token, id:user._id
                })
            } else {
                res.status(401).json({
                    message: "Email and password did not match"
                })
            }
        } else {
            res.status(401).json({
                message: "Email and password did not match"
            })
        }
    } catch (error) {
        console.log("Error occurred", error.message)
        res.status(500).json({
            message: "Internal Server Error"
        })
    }
})

router.post('/register', async (req, res) => {
    const { name, email, password } = req.body

    try {
        const hashed = await bcrypt.hash(password, 10)
        const user = new User({ name, email, password: hashed })
        await user.save()
        res.status(200).json({
            message: "user saved successfully"
        })
    } catch (error) {
        console.log("Error occurred", error.message)
        res.status(500).json({
            message: "Internal Server Error"
        })
    }
})

router.get('/get/friends', async(req, res)=>{
    const friends = await User.find()
    if(friends){
        res.status(200).json({
            friends: friends,
            message:"success"
        })
    }else{
        res.status(403).json({
            error:"no data found at that api"
        })
    }
})
router.delete('/delete/friend/:id', async(req, res)=>{
    const id = req.params.id
    const friend_delete = await User.findByIdAndDelete(id)
    if(friend_delete){
        res.status(200).json({
            friends: friend_delete,
            message:"success deleted"
        })
    }else{
        res.status(403).json({
            error:"no friend found on that id"
        })
    }
})
module.exports = router