const express = require('express')
const friendRouter = express.Router()
const FriendMessage = require('../models/friendMessage')


friendRouter.post("/create/friend/message", async (req, res) => {
    const { senderId, receiverId, message} = req.body
    const newOne = new  FriendMessage({ senderId, receiverId, message })
    newOne.save()
    res.status(200).json({
        message:"chat room created",
        result: newOne
    })
})

friendRouter.get("/get/friend_messages/:senderId/:name", async (req, res) => {
    const { senderId, name} = req.params;
    try {
        const messages = await FriendMessage.find({ senderId, receiver_name:name });
        console.log(messages)
        res.status(200).json({
            message: "your chats are successfully fetched",
            chats: messages
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal server error" });
    }
});


friendRouter.put("/update/friend_messages/:senderId/:name/:message_id", async (req, res) => {
    const { senderId, name, message_id} = req.params;
    const message = req.body.message
    try {
        const messages = await FriendMessage.findByIdAndUpdate(message_id,{senderId, name, message});
               
        res.status(200).json({
            message: "your chats are successfully fetched",
            chats: messages
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal server error" });
    }
});


friendRouter.get("/get/friend_messages/:senderId/:name/:message_id", async (req, res) => {
    const {message_id} = req.params;
    try {
        const messages = await FriendMessage.findByIdAndDelete(message_id);
        console.log(messages)
        res.status(200).json({
            message: "this  message is successfully deleted fetched",
            chats: messages
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: "Internal server error" });
    }
});


module.exports = friendRouter