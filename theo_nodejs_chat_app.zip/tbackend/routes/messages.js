const express = require('express')
const messageRouter = express.Router()
const Message = require('../models/chatMessage')


messageRouter.post("/create/message", async (req, res) => {
    const { name } = req.body
    const message = new Message({
        name
    })
    message.save()
    res.status(200).json({
        message:"chat room created",
        message
    })
})

messageRouter.get("/get/messages/:group", async (req, res) => {
    const {group} = req.params
    
    const messages =await Message.find({group})
       try {
     
    res.status(200).json({
        message:"messages are successfully fetched",
        mines:messages
    })
   } catch (error) {
    console.log(error)
   }
})

module.exports = messageRouter