const mongoose = require('mongoose')
const friendChatSchema = new mongoose.Schema({
senderId:{
    type:String,
},
receiver_name:{
    type:String,
},
message:{
    type:String
},
date:{
    type:Date,
    default:Date.now
}

})
const FriendMessage = mongoose.model('FriendMessage', friendChatSchema)
module.exports = FriendMessage