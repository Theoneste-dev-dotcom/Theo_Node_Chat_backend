const mongoose = require('mongoose')
const messageSchema = new mongoose.Schema({
    group: String,
    message: String,
   // Optional: You can also store the sender of the message
    timestamp: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Message', messageSchema)

