const mongoose = require('mongoose')
const chatRoom = new mongoose.Schema({
    name:{
        type:String,
        required:'name is required',
    },
  
})

module.exports = mongoose.model('ChatRoom', chatRoom)

